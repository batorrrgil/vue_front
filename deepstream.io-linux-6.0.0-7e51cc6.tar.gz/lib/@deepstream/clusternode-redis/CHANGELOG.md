## [1.0.0] - 2020-04-24

- First official release