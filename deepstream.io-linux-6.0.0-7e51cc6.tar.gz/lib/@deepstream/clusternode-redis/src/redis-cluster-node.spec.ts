describe('the message connector has the correct structure', () => {
  it ('does nothing yet', () => {
    // We need generic tests for plugin, rather than copying and pasting them everywhere
  })
})
