[2.0.0] 2019-10-27

### Feat

Upgrading all dependencies and getting it compatible with V4

[1.0.0] 2016-07-01
