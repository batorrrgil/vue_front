export const config = {
  serverLocation: process.env.MEMCACHED_URL || "localhost:11211",
  lifetime: 1000
}